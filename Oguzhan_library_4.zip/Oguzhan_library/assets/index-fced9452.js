import{P as f}from"./index-adc026ae.js";export{f as default};
