import{P as f}from"./index-650c5ea1.js";export{f as default};
